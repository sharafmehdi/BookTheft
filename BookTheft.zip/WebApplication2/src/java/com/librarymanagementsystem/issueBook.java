package com.librarymanagementsystem;


import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import java.text.SimpleDateFormat;  
import java.util.Date;   
import java.lang.Math;


@WebServlet(name = "issueBook", urlPatterns = {"/issueBook"})
public class issueBook extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            
            int quantity=0, newquan=0;
            int def=0;
            long issuenumber;
            
            
           boolean setQuantity=false;
        boolean bookCodeFound=false;
        boolean insertreturn=false;
        int studentid = Integer.parseInt(request.getParameter("studentid"));
        String bookcode = request.getParameter("bookcode");
        String issueDat = (String)request.getParameter("issueDate");
        int bookid=0;
        String bookname="";
        
        Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");
            
Statement st=con.createStatement();
String q="select * from books";
ResultSet rs=st.executeQuery(q);

while(rs.next())
{
    String bcode=rs.getString("bookcode");
    if(bcode.equals(bookcode))
    { 
        bookid=rs.getInt("bookid");
        bookname=rs.getString("bookName");
        bookcode=rs.getString("bookcode");
        quantity=rs.getInt("quantity");
        if(quantity<0 || quantity==0)
        {
            break;
        }
        bookCodeFound=true;
    }
}

if(bookCodeFound)
{
try
        {
            issuenumber = (long)(Math.random() * 21485);
        SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date issueDate = format.parse(issueDat);
        java.sql.Date sqlDate = new java.sql.Date(issueDate.getTime());
        
        q="insert into issueBook(issuenumber,bookid,bookName,bookcode,id,issueDate) values(?,?,?,?,?,?)";
        PreparedStatement pstmt=con.prepareStatement(q);
        pstmt.setLong(1,issuenumber);
        pstmt.setInt(2,bookid);
        pstmt.setString(3,bookname);
        pstmt.setString(4,bookcode);
        pstmt.setInt(5,studentid);
        pstmt.setDate(6,sqlDate);
        pstmt.executeUpdate();
        setQuantity=true;
        insertreturn=true;
        
        if(setQuantity)
        {
        newquan=quantity-1;
        q="update books set quantity=? where bookcode=?";
        pstmt=con.prepareStatement(q);
        pstmt.setInt(1,newquan);
        pstmt.setString(2,bookcode);
        pstmt.executeUpdate(); 
        }
        

        if(insertreturn)
        {
         String q1="insert into returnBook(issuenumber,bookid,bookName,bookcode,id,issueDate,returned) values(?,?,?,?,?,?,?)";
         PreparedStatement pstm=con.prepareStatement(q1);
         pstm.setLong(1,issuenumber);
         pstm.setInt(2,bookid);
         pstm.setString(3,bookname);
         pstm.setString(4,bookcode);
         pstm.setInt(5,studentid);
         pstm.setDate(6,sqlDate);
         pstm.setInt(7,def);
         pstm.executeUpdate();
         pstm.close();
        }
        
       out.println("Book issued successfully.");
       rs.close();
       con.close();
       pstmt.close();
        }
        catch (Exception ex) {
        ex.printStackTrace();

    }
}
else
{
    if(quantity<0 || quantity==0)
        {
            out.println("The book is not available in the Library.");
        }
    else
    {
    out.println("Please enter a valid Book Code.");
    }
}
rs.close();
            
        }
}

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    

}