package com.librarymanagementsystem;


import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;  


/**
 *
 * @author syeds
 */
@WebServlet(name = "AdminLoginCheck", urlPatterns = {"/AdminLoginCheck"})
public class AdminLoginCheck extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
        boolean logincheck=false;
        boolean logincheck1=false;
        String user = request.getParameter("username");
        String pass = request.getParameter("password");
        String fname="";
        String lname="";
        int a=0;
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");
            
Statement st=con.createStatement();
String q="select * from adminlogin";
ResultSet rs=st.executeQuery(q);

while(rs.next())
{
    String login=rs.getString("username");
    String code=rs.getString("password");
    if(login.equals(user) && code.equals(pass))
    { 
    a=rs.getInt("id");
    fname=rs.getString("fName");
    lname=rs.getString("lName");
    logincheck=true;
    break;
    }
}


if(logincheck)
{
    HttpSession session = request.getSession();
    session.setAttribute("usernamevalue",user);
    session.setAttribute("firstname1",fname);
    session.setAttribute("lastname1",lname);
    session.setAttribute("rollno",a);
    session.setAttribute("password1",pass);
    request.getRequestDispatcher("adminwelcome.jsp").forward(request, response);
}
else
{
   out.println("Incorrect password."); 
}
    }
}

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminLoginCheck.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminLoginCheck.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
