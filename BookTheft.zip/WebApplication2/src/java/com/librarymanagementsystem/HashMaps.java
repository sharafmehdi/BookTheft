package com.librarymanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

class Work {
    private int Id;
    private String Fname;
    private String Lname;
    private String username;
    private String password;
    private String course;
    private long mobile;
    private String address;
    
    
    
    public Work(){}
    public Work(int id, String fname,String lname, String user, String cours, long mob, String addr){
        this.Id = id;
        this.Fname = fname;
        this.Lname = lname;
        this.username = user;
        this.course=cours;
        this.mobile = mob;
        this.address = addr;
    }
    
    public int getId(){
        return this.Id;
    }
    
    public String getFname(){
        return this.Fname;
    }
    
       public String getLname(){
        return this.Lname;
    }
       
     public String getUsername(){
        return this.username;
    }
     
     public String getPassword(){
        return this.password;
    }
     public String getCourse(){
        return this.course;
    }
     
     public long getMobile(){
        return this.mobile;
    }
     
     public String getAddress(){
        return this.address;
    }
     
     
     // create a tostring method to diplay data
     public String ToString(){
         return this.Id+" "+this.Fname+" "+this.Lname+" "+this.username+" "+this.password+" "+this.mobile+" "+this.address;
     }
    
}

public class HashMaps {
   
    public static Connection getConnection(){
        
        Connection con = null;
        
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/lms", "root", "root");
        } catch (SQLException ex) {
            Logger.getLogger(Work.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return con;
    }
    
    public static void main(String[] args){

        HashMap<Integer,Work> map = new HashMap<Integer,Work>();
        Statement st = null;
        ResultSet rs = null;
        Connection con = getConnection();
        Work u;
        
        try{
             st = con.createStatement();
            rs = st.executeQuery("SELECT * FROM studentlogin");
            while(rs.next()){
                Integer id = rs.getInt("id");
                String fname = rs.getString("fName");
                String lname = rs.getString("lName");
                String usern = rs.getString("username");
                String course = rs.getString("course");
                long mob = rs.getLong("mobile");
                String addre = rs.getString("address");

                
                u = new Work(id, fname,lname,usern,course,mob,addre);
                
                // set data in the hashmap
                map.put(id, u);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        // display data from the hashmap
        for(Integer i : map.keySet()){
            Work us = map.get(i);
            System.out.println(us.getId()+" "+us.getFname()+" "+us.getLname()+" "+us.getUsername()+" "+us.getCourse()+" "+us.getMobile()+" "+us.getAddress());
        }
        }
}
