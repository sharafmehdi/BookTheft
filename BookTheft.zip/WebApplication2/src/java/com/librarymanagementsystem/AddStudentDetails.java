package com.librarymanagementsystem;


import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author syeds
 */
@WebServlet(name = "AddStudentDetails", urlPatterns = {"/AddStudentDetails"})
public class AddStudentDetails extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
        
        String first = request.getParameter("fName");
        String last = request.getParameter("lName");
        String user = request.getParameter("username");
        String pass = request.getParameter("password");
        String coursename = request.getParameter("coursename");
        String mobile = request.getParameter("mobile");
        String address = request.getParameter("address");
        

Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");
            

String q="insert into studentlogin(fName,lName,username,password,course,mobile,address) values(?,?,?,?,?,?,?)";
PreparedStatement pstmt=con.prepareStatement(q);
pstmt.setString(1,first);
pstmt.setString(2,last);
pstmt.setString(3,user);
pstmt.setString(4,pass);
pstmt.setString(5,coursename);
pstmt.setString(6,mobile);
pstmt.setString(7,address);
pstmt.executeUpdate();

out.println("Record added!");

        }
}

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    

}
