package com.librarymanagementsystem;


import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import java.util.*;
import java.lang.*;
import java.text.*;

/**
 *
 * @author syeds
 */
@WebServlet(name = "StudentLoginCheck", urlPatterns = {"/StudentLoginCheck"})
public class StudentLoginCheck extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
        boolean logincheck=false;
        String user = request.getParameter("username");
        String pass = request.getParameter("password");
        String fname="";
        String lname="";
        int a=0;
        String course="";
        String address="";
        long mobile=0;
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");
            
Statement st=con.createStatement();
String q="select * from studentlogin";
ResultSet rs=st.executeQuery(q);

while(rs.next())
{
    String login=rs.getString("username");
    String code=rs.getString("password");
    
    if(login.equals(user) && code.equals(pass))
    {
    a=rs.getInt("id");
    fname=rs.getString("fName");
    lname=rs.getString("lName");
    course=rs.getString("course");
    mobile=rs.getLong("mobile");
    address=rs.getString("address");
    logincheck=true;
    break;
    }
}
if(logincheck)
{
    java.util.Date date = new java.util.Date();
    SimpleDateFormat tdate = new SimpleDateFormat("yyyy-MM-dd");
    HttpSession session = request.getSession();
    session.setAttribute("usernamevalue",user);
    session.setAttribute("firstname1",fname);
    session.setAttribute("lastname1",lname);
    session.setAttribute("rollno",a);
    session.setAttribute("course1",course);
    session.setAttribute("mobile1",mobile);
    session.setAttribute("address1",address);
    session.setAttribute("password1",pass);
    session.setAttribute("date",tdate.format(date));
    request.getRequestDispatcher("studentwelcome.jsp").forward(request, response);
}
else
{
   out.println("Incorrect password or username."); 
}
    }
}

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(StudentLoginCheck.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(StudentLoginCheck.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
