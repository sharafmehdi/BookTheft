package com.librarymanagementsystem;

import java.util.Random;
import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author syeds
 */



@WebServlet(name = "AddBooks", urlPatterns = {"/AddBooks"})
public class AddBooks extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
        
            int leftLimit = 65; // letter 'a'
    int rightLimit = 90; // letter 'z'
    int targetStringLength = 4;
    Random random = new Random();
    StringBuilder buffer = new StringBuilder(targetStringLength);
    for (int i = 0; i < targetStringLength; i++) {
        int randomLimitedInt = leftLimit + (int) 
          (random.nextFloat() * (rightLimit - leftLimit + 1));
        buffer.append((char) randomLimitedInt);
    }
    String generatedString = buffer.toString();
    
        String bookname = request.getParameter("bookName");
        String author = request.getParameter("author");
        String subject = request.getParameter("subj");
        String quan = request.getParameter("quantity");
        Integer quantity = Integer.parseInt(quan);
        String code=generatedString;
        
        
        
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");
            
String q="insert into books(bookName,author,dept,quantity,bookcode) values(?,?,?,?,?)";
PreparedStatement pstmt=con.prepareStatement(q);
pstmt.setString(1,bookname);
pstmt.setString(2,author);
pstmt.setString(3,subject);
pstmt.setInt(4,quantity);
pstmt.setString(5,code);
pstmt.executeUpdate();

out.println("Book added!");
    }
}

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    
}
