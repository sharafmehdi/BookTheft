package com.librarymanagementsystem;


import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import java.text.SimpleDateFormat;  
import java.util.Date; 

@WebServlet(name = "DeleteBook", urlPatterns = {"/DeleteBook"})
public class DeleteBook extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            
            boolean checkDelete=false;
        int bookid = Integer.parseInt(request.getParameter("value"));
        
        
        Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");

Statement st=con.createStatement();
String q="select * from books";
ResultSet rs=st.executeQuery(q);

while(rs.next())
{
    int bid=rs.getInt("bookid");
    if(bid==bookid)
    {
        checkDelete=true;
    }
}
            


if(checkDelete)
{
st=con.createStatement();
q="delete from books where bookid=?";
PreparedStatement pstmt=con.prepareStatement(q);
pstmt.setInt(1,bookid);
pstmt.executeUpdate();
pstmt.close();
out.println("Book Deleted.");
}

else
{
    out.println("Please enter a valid Book ID.");
} 
            
        }
}

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    

}