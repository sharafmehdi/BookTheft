package com.librarymanagementsystem;


import java.io.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;
import java.text.SimpleDateFormat;  
import java.util.Date;  


@WebServlet(name = "returnBook", urlPatterns = {"/returnBook"})
public class returnBook extends HttpServlet {

   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            int quantity=0, newquan=0;
            boolean setQuantity=false;
            boolean getissueDetails=false;
        boolean returnbookCodeFound=false;
        boolean changeDate=false;
        boolean changeStatus=false;
        boolean ifIssued=false;
        long issuenumbers=0;
        int studentid = Integer.parseInt(request.getParameter("studentid"));
        String bookcode = request.getParameter("bookcode");
        String returnDat = (String)request.getParameter("returnDate");

        
        Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","root");
            
Statement st=con.createStatement();
String q="select * from books";
ResultSet rs=st.executeQuery(q);

while(rs.next())
{
    String bcode=rs.getString("bookcode");
    if(bcode.equals(bookcode))
    { 
        quantity=rs.getInt("quantity");
        getissueDetails=true;
        //out.println("Before1");
    }
}



if(getissueDetails)
{
try {
    q="select * from issueBook";
rs=st.executeQuery(q);

while(rs.next())
{
    String bcode=rs.getString("bookcode");
    int studid=rs.getInt("id");
    if(bcode.equals(bookcode) && studid==studentid)
    {
        issuenumbers=(long)(rs.getInt("issuenumber"));
        ifIssued=true;
    }
}

if(ifIssued)
{
    returnbookCodeFound=true;
    setQuantity=true;
}
else
{
    out.println("Kindly issue the Book first then try returning.");
}


if(returnbookCodeFound)
{

         q="delete from issueBook where issuenumber=?";
        PreparedStatement pstmt=con.prepareStatement(q);
        pstmt.setLong(1,issuenumbers);
        pstmt.executeUpdate();

        
        
        
         if(setQuantity)
        {  
        newquan=quantity+1;
        q="update books set quantity=? where bookcode=?";
        pstmt=con.prepareStatement(q);
        pstmt.setInt(1,newquan);
        pstmt.setString(2,bookcode);
        pstmt.executeUpdate();  
        changeDate=true;
        } 
         
        if(changeDate)
        {
            SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date returnDate = format.parse(returnDat);
        java.sql.Date sqlDate = new java.sql.Date(returnDate.getTime());
            q="update returnBook set returnDate=? where issuenumber=?;";
            PreparedStatement pstm=con.prepareStatement(q);
            pstm.setDate(1,sqlDate);
            pstm.setLong(2,issuenumbers);
            pstm.executeUpdate();
            pstm.close();
            changeStatus=true;
        }
        
        if(changeStatus)
        {
            int stat=1;
            q="update returnBook set returned=? where issuenumber=?;";
            PreparedStatement pstm=con.prepareStatement(q);
            pstm.setInt(1,stat);
            pstm.setLong(2,issuenumbers);
            pstm.executeUpdate();
            pstm.close();
        }
       out.println("Book returned successfully.");
}
}
        catch (Exception ex) {
        ex.printStackTrace();
    }
}
else
{
    out.println("Please enter a valid Book Code.");
        }
/* if(ifIssued==false)
{
   out.println("Kindly issue the Book first then try returning."); 
} */

}
   }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddStudentDetails.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    

}